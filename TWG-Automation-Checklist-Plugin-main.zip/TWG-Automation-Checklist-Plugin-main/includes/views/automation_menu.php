<style>
    .yoast-notice { display:none; }
   .twg-automation-menu hr { border-color:#888; }
   .twg-automation-menu .twg-error { color:red;  }
   .twg-automation-menu .twg-loader {    position: absolute;
       margin-top: -105px;
       margin-left: 510px;
       width: 100px;  }
    .twg-automation-header {     position: fixed;
        width: 100%;
        top:30px;
        background: #FFF;
        padding: 0 10px;
        margin-left: -10px;
        border-bottom: 2px solid #888;  padding-bottom:10px; }
   .twg-automation-menu #automation_content { margin-top:120px; }
   .twg-automation-menu .twg-success { color:#32a80f; font-weight:bold; }
   .twg-automation-menu .twg-default { font-style:italic; }
   .twg-automation-menu .twg-primary { font-weight:600; font-size:14px; margin-top:10px; }
   .twg-automation-menu .twg-secondary { margin-bottom:10px; }
   .twg-automation-menu #automation_content h2 { border-bottom:1px #CCC solid; padding-bottom:5px; margin-top:20px; }
   .twg-automation-menu .twg-section-header {
       padding: 10px 5px;
       color: white;
       background: #5686b9;
       border: 1px solid #CCC;
   }
   .twg-checkbox { display:inline-block; margin-left:20px; margin-top:3px;}


   .twg-report-item { margin-bottom:10px; border:1px solid #DDD; padding:5px;}
   .twg-report-item .twg-report-issue {  color:#a02033; font-weight:bold; }
   .twg-report-item.has-issue {
       background: #F2DEDE;
       border-color: #a02033;
   }
   .twg-automation-menu #automation_content h2 {
       background: white;
       padding-top: 0;
       padding-left: 0;
       margin-top: 15px;
       font-weight: normal;
   }

   .twg-automation-menu #automation_content h2 span { font-weight:bold; }
   .twg-automation-menu #automation_content .twg-report-issue { margin-bottom:5px; }
   .twg-automation-menu #automation_content h3 { font-weight:normal; }
   .twg-automation-menu #automation_content .twg-report-issue span,
   .twg-automation-menu #automation_content .twg-report-info span { font-weight:bold; }
   .twg-report-item { background:#FCF8E3; }
   .twg-report-item.no-issue { background:#DFF0D8; border-color:green; }
   .twg-report-panel { background:#FFF; margin-top:10px !important; padding:0px 10px 10px 10px;
       border:1px solid #CCC;
   }

    .twg-report-item.quick-overview { background:#D9EDF7; border-color:#31708f; }
</style>
<div class="twg-automation-menu">
<div class="twg-automation-header">
    <h1>TWG Checklist Automation & Reporting</h1>

    <button  class="button button-primary button-large" id="automation_start">Run Automation & Report</button>

    <div class="twg-checkbox"><label>Disable Report <input id="reportDisabled" name="report_disabled" type="checkbox" value="1" /></label></div>
    <div  class="twg-checkbox"><label>Disable Automation <input id="automationDisabled" name="automation_disabled" type="checkbox" value="1" /></label></div>
    <div  class="twg-checkbox"><label>Exclude Blog Posts <input id="blogPostExclusion" name="blog_exclusion" type="checkbox" value="1" /></label></div>


    <div style="display:none;" id="automation_running">
    <h2>Automation/Report Running...<br/><small>Sit back and relax let the robots and wizards handle it</small></h2>
        <img class="twg-loader" src="<?=$this->assets_url?>images/gears.gif" />
    </div>
</div>

    <div id="automation_content">

    </div>
</div>

<script>
    jQuery(document).ready(function($){

        $(document).on("click",".show-report-issues",function(){
                 $(".twg-report-panel").hide();
                $(".twg-report-panel.parent-issue").show();
                return false;
        });

        $(document).on("click",".show-report-all",function(){
                $(".twg-report-panel").show();
                return false;
        });

            $(document).on("click","#automation_start",function(){
                $('.twg-checkbox').hide();
              $(this).hide(function() {
                  $("#automation_running").fadeIn();
                  automation_call("start");
              });

            });

            function automation_call($call) {
                var data = {};
                data.action = "twg_automate_checklist";
                if($call) {
                    data.call = $call;
                    if($('#reportDisabled').is(":checked")) {
                        data.report_disabled = 1;
                    }
                    if($('#automationDisabled').is(":checked")) {
                        data.automation_disabled = 1;
                    }
                    if($('#blogPostExclusion').is(":checked")) {
                        data.blog_exclusion = 1;
                    }
                    $.post(ajaxurl, data, function ($rsp) {
                        if(!$rsp.error) {
                            $("#automation_content").append($rsp.content);
                            if($rsp.call) {
                                automation_call($rsp.call);
                            } else {
                                $(".twg-automation-header h2").text("Automation/Reporting Complete!").css("color","#5CB85C");
                                $(".twg-automation-header h2").after('<button class="btn btn-default show-report-issues">Show Issues Only</button>' +
                                    '<button class="btn btn-default show-report-all">Show All</button>');
                                $(".twg-automation-header .twg-loader").hide();
                                $( ".has-issue" ).each(function( index ) {
                                        $(this).parent().addClass('parent-issue');
                                });
                            }
                        } else {
                            $("#automation_content").html("<h2 class='twg-error'>AN ERROR HAS OCCURRED!</h2>").append($rsp.error);
                        }
                    });
                }
            }
    });


</script>


