<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class TWG_Automation_Checklist {

	/**
	 * The single instance of TWG_Automation_Checklist.
	 * @var 	object
	 * @access  private
	 * @since 	1.0.0
	 */
	private static $_instance = null;

	/**
	 * Settings class object
	 * @var     object
	 * @access  public
	 * @since   1.0.0
	 */
	public $settings = null;

	/**
	 * The version number.
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $_version;

	/**
	 * The token.
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $_token;

	/**
	 * The main plugin file.
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $file;

	/**
	 * The main plugin directory.
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $dir;

	/**
	 * The plugin assets directory.
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $assets_dir;

	/**
	 * The plugin assets URL.
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $assets_url;

	/**
	 * Suffix for Javascripts.
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */
	public $script_suffix;

	/**
	 * Constructor function.
	 * @access  public
	 * @since   1.0.0
	 * @return  void
	 */
	public function __construct ( $file = '', $version = '1.0.0' ) {
		$this->_version = $version;
		$this->_token = 'twg_automation_checklist';

		// Load plugin environment variables
		$this->file = $file;
		$this->dir = dirname( $this->file );
		$this->assets_dir = trailingslashit( $this->dir ) . 'assets';
		$this->assets_url = esc_url( trailingslashit( plugins_url( '/assets/', $this->file ) ) );

		$this->script_suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		register_activation_hook( $this->file, array( $this, 'install' ) );

		// Load frontend JS & CSS
		//	add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ), 10 );
		//	add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 10 );

		// Load admin JS & CSS
		//	add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ), 10, 1 );
		//	add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_styles' ), 10, 1 );

		// Load API for generic admin functions
		if ( is_admin() ) {
			$this->admin = new TWG_Automation_Checklist_Admin_API();
		}

		add_action( 'admin_menu', array($this,'register_automation_menu') );

		add_action( 'wp_ajax_twg_automate_checklist', array($this,'automation_controller') );


		// Handle localisation
		$this->load_plugin_textdomain();
		add_action( 'init', array( $this, 'load_localisation' ), 0 );

	} // End __construct ()


	public function register_automation_menu() {
		add_menu_page( 'TWG Automation Checklist/Report', 'TWG Automation', 'manage_options', 'twg-automation-checklist', array($this,'automation_menu'),'', 999 );
	}

	public function automation_menu() {

		include_once ($this->dir."/includes/views/automation_menu.php");

	}

	/*
	 *  Ajax Controller Function runs calls and returns the data
	 */
	public function automation_controller() {

		header('Content-type: application/json');
		$automation_call_order = array("general_wp_automate");
		if($_POST['blog_exclusion']==1) {
			$report_call_order = array("phone_report","theme_report","pages_report","widgets_report","footer_report","header_report");
		} else {
			$report_call_order = array("phone_report","theme_report","pages_report","posts_report","widgets_report","footer_report","header_report");
		}

		if($_POST['automation_disabled']==1 && $_POST['report_disabled']==1) {
			$json['content'] = 'Nothing was ran... You have both automation and reporting disabled.';
			echo json_encode($json);
			wp_die();
		}
		else if($_POST['automation_disabled']==1) {
			$automation_call_order = array();
		}
		else if($_POST['report_disabled']==1) {
			$report_call_order = array();
		}
		$call_order = array_merge($automation_call_order,$report_call_order);
		$json = array();
		if($_POST['call']!="start") {
			$call = $_POST['call'];
			$json = $this->$call();
		} else {
			$first_call = $call_order[0];
			$json = $this->$first_call();
		}

		if($call_order[array_search($_POST['call'],$call_order)+1]) {
			$json['call'] = $call_order[array_search($_POST['call'], $call_order) + 1];
		} else {

		}

		echo json_encode($json);
		wp_die();

	}

	public function theme_report() {
		global $redux;
		$json['content'] = "";
		if(function_exists("shoestrap_getVariable")) {
			$json['content'] .= "<div class='twg-report-panel'>";
			$json['content'] .= "<h2><span>Theme Configuration Scan</span></h2>";
			$json['content'] .= "<h3>Checking for Favicon</h3>";
			if(trim(shoestrap_getVariable('favicon')['url'])!="") {
				$json['content'] .= "<div class='twg-report-item no-issue'>";
				$json['content'] .= "<div class='twg-report-info'>Favicon is Configured Properly</div>";
			} else {
				$json['content'] .= "<div class='twg-report-item has-issue'>";
				$json['content'] .= "<div class='twg-report-issue'>No Favicon Configured! </div>";
			}
			$json['content'] .= "</div>";
			$json['content'] .= "<h3>Checking for Client Login Logo</h3>";
			if(trim(shoestrap_getVariable('login_logo')['url'])!="") {
				$json['content'] .= "<div class='twg-report-item no-issue'>";
				$json['content'] .= "<div class='twg-report-info'>Login Logo is Configured Properly</div>";
			} else {
				$json['content'] .= "<div class='twg-report-item has-issue'>";
				$json['content'] .= "<div class='twg-report-issue'>No Login Logo Configured! </div>";
			}
			$json['content'] .= "</div>";
			$json['content'] .= "</div>";
		}

		return $json;
	}

	public function get_matched_phone_numbers($content) {
		$out = array();
		$matched = array();
		$matches = preg_match_all('/\(?\d{3}\)?[-\s\.]?\d{3}[-\s\.]?\d{4}/i',$content,$out);
		foreach($out as $mats) {
			foreach($mats as $mat) {
				$matched[] = $mat;
			}
		}
		return $matched;
	}

	public function process_links($links) {


	}


	public function get_links($content) {
		if(trim($content)) {
			$html = str_get_html($content);
			$links = array();
			foreach($html->find('a') as $e => $element)
			{
				$links[$e]['target'] = $element->target;
				$links[$e]['href'] = $element->href;
				$links[$e]['text'] = $element->plaintext;
			}
			return $links;
		} else {
			return false;
		}

	}


	public function get_images($content) {
		if(trim($content)) {
			$html = str_get_html($content);
			$links = array();
			foreach($html->find('img') as $e => $element)
			{
				$links[$e]['src'] = $element->src;
				$links[$e]['alt'] = $element->alt;
			}
			return $links;
		} else {
			return false;
		}

	}

	// Return words per page, top keywords, etc.
	public function get_keyword_report($content){

		//strip tags from content
		$content = strtolower(wp_strip_all_tags($content,true));
		$report = array();
		//Words to ignore when looking at top keywords
		$stop_words = $this->get_stop_words();

		$report['word_count'] = str_word_count($content);
		$report['keywords'] = array_count_values(array_diff(str_word_count($content,1),$stop_words));
		arsort(	$report['keywords'] );
		$report['keywords']  = 	array_slice($report['keywords'],0,5);
		return $report;

	}

	/* Loop through content links and report on any broken links and other issues */
	public function pages_report($type="page") {
		$remote_checks =  array();
		$json['content'] = '';
		$pages = $this->get_page_post_info($type);
		$site_url = get_site_url();
		foreach($pages as $page_id => $page) {
			$links = $this->get_links($page['content']);
			$keyword_report = $this->get_keyword_report($page['content']);
			$json['content'] .= "<div class='twg-report-panel'>";
			$json['content'] .= "<h2><span>".ucfirst($type).":</span> ".$page['title']."  <small><a target='_blank' href='".get_permalink($page_id)."'>View Page</a></small> </h2>";

			//Quick Overview
			$json['content'] .= "<h3>Words Overview</h3>";
			$json['content'] .= "<div class='twg-report-item quick-overview'>";
			$json['content'] .= "<b>Word Count:</b> ".$keyword_report['word_count'];
			if($keyword_report['keywords']) {
				$json['content'] .= "<br/><b>Top 5 Words:</b> | ";
				foreach($keyword_report['keywords'] as $keyword => $count) {
					$json['content'] .= "$keyword ( $count ) | ";
				}
			}
			$json['content'] .= "</div>";


			//Link Scanning
			$json['content'] .= "<h3>Link Scan</h3>";


			if($links) {
				foreach ($links as $link) {

					if(substr(trim($link['href']),0,1)=="#" || stristr($link['href'],"tel:") || stristr($link['href'],"mailto:") || stristr($link['href'],"sms:")) {
						continue;
					}

					if(stristr($link['href'],"#")){
						$link['href'] = explode("#",$link['href'])[0];
					}

					$target_issue = false;
					if (stristr($link['href'], "http://") || stristr($link['href'], "https://")) {
						$remote_url = $link['href'];
						if( !$remote_checks[ $remote_url ] ) {
							$remote_checks[ $remote_url ] = wp_remote_head( $remote_url );
							if ( $link['target'] != "_blank" && ! stristr( $remote_url, $site_url ) ) {
								$target_issue = true;
							}
						}
					} else {
						$remote_url  = $site_url . $link['href'];
						if(!$remote_checks[$remote_url]) {
							$remote_checks[$remote_url] = wp_remote_head( $remote_url );
						}
					}

					if( !is_wp_error($remote_checks[ $remote_url ] )) {
						if ($remote_checks[$remote_url ] ['response']['code'] != "200" || $target_issue) {
							$json['content'] .= "<div class='twg-report-item has-issue'>";
							$json['content'] .= "<div class='twg-report-info'>" . $link['href'] . "</div>";
							if ($remote_checks[$remote_url ]['response']['code'] != "200") {
								$json['content'] .= "<div class='twg-report-issue'>ISSUE: " . $remote_checks[ $remote_url ]['response']['code'] . "</div>";
							}
							if ($target_issue) {
								$json['content'] .= "<div class='twg-report-issue'>ISSUE: External link does not open in a new window.</div>";
							}
						} else {
							$json['content'] .= "<div class='twg-report-item no-issue'>";
							$json['content'] .= "<div class='twg-report-info'>" . $link['href'] . "</div>";
						}
						$json['content'] .= "</div>";
					} else {
						$json['content'] .= "<div class='twg-report-item has-issue'>";
						$json['content'] .= "<div class='twg-report-info'>" . $link['href'] . "</div>";
						$json['content'] .= "<div class='twg-report-issue'>ISSUE: Most likely invalid URL view error below.</div>";

						$json['content'] .= pre_print($remote_checks[ $remote_url ]->errors,true);
						$json['content'] .= "</div>";
					}




				}
			} else {
				$json['content'] .= "<div class='twg-report-item'>";
				$json['content'] .= "<div class='twg-report-info'>No links on this page</div>";
				$json['content'] .= "</div>";
			}

			// Meta Title & Description Checking
			$meta_title_issue = "";
			$meta_description_issue = "";
			$json['content'] .= "<h3>Meta Title & Description</h3>";
			if(trim($page['meta_title'])=="") {
				$meta_title_issue = "<div class='twg-report-issue'>Meta Title is empty</div>";
			} else if(strlen($page['meta_title'])>60) {
				$meta_title_issue = "<div class='twg-report-issue'>Meta Title has more than 60 characters</div>";
			}
			if(trim($page['meta_description'])=="") {
				$meta_description_issue = "<div class='twg-report-issue'>Meta Description is empty</div>";
			} else if(strlen($page['meta_description'])>160) {
				$meta_title_issue = "<div class='twg-report-issue'>Meta Description has more than 160 characters</div>";
			}



			if($meta_title_issue || $meta_description_issue) {
				$json['content'] .= "<div class='twg-report-item has-issue'>";
				$json['content'] .= "<div class='twg-report-info'><span>Meta Title:</span> ".$page['meta_title']."</div>";
				$json['content'] .= $meta_title_issue;
				$json['content'] .= "<div class='twg-report-info'><span>Meta Description:</span> ".$page['meta_description']."</div>";
				$json['content'] .= $meta_description_issue;
			} else {
				$json['content'] .= "<div class='twg-report-item no-issue'>";
				$json['content'] .= "<div class='twg-report-info'><span>Meta Title:</span> ".$page['meta_title']."</div>";
				$json['content'] .= "<div class='twg-report-info'><span>Meta Description:</span> ".$page['meta_description']."</div>";
			}
			$json['content'] .="</div>";

			//Image alt tag checking
			$images = $this->get_images($page['content']);
			$json['content'] .= "<h3>Image Scan</h3>";
			$image_count = 0;
			$alt_missing = 0;
			$image_issue = "";
			$alt_tags = "";
			if($images) {
				foreach ($images as $image) {
					if (trim($image['alt']) != "") {
						$alt_tags .= "<div class='twg-report-info'><span>ALT:</span> " . $image['alt'] . "</div>";
					} else {
						$alt_missing++;
					}
					$image_count++;
				}
				if ($alt_missing) {
					$json['content'] .= "<div class='twg-report-item has-issue'>";
					$json['content'] .= "<div class='twg-report-issue'>Alt Text missing from $alt_missing image(s)</div>";
					$json['content'] .= "<div class='twg-report-info'><span>Image Count:</span> " . $image_count . "</div>";
					$json['content'] .= $alt_tags;
				} else {
					$json['content'] .= "<div class='twg-report-item no-issue'>";
					$json['content'] .= "<div class='twg-report-info'><span>Image Count:</span> " . $image_count . "</div>";
					$json['content'] .= $alt_tags;
				}

				$json['content'] .= "</div>";
			} else {
				$json['content'] .= "<div class='twg-report-item'>";
				$json['content'] .= "<div class='twg-report-info'>No images on this page</div>";
				$json['content'] .= "</div>";
			}
			$json['content'] .= "</div>";

		}
		return $json;
	}

	public function posts_report() {
		return $this->pages_report("post");
	}

	public function footer_report() {
		$json['content'] = '';
		$site_url = get_site_url();
		$footer = $this->get_footer_content();

		$links = $this->get_links($footer);
		$json['content'] .= "<div class='twg-report-panel'>";
		$json['content'] .= "<h2><span>Footer Content</span>  </h2>";

		//Link Scanning
		$json['content'] .= "<h3>Link Scan</h3>";
		if($links) {
			foreach ($links as $link) {

				if(substr(trim($link['href']),0,1)=="#" || stristr($link['href'],"tel:") || stristr($link['href'],"mailto:") || stristr($link['href'],"sms:")) {
					continue;
				}

				if(stristr($link['href'],"#")){
					$link['href'] = explode("#",$link['href'])[0];
				}

				$target_issue = false;
				if (stristr($link['href'], "http://") || stristr($link['href'], "https://")) {
					$remote = wp_remote_head($link['href']);
					if ($link['target'] != "_blank" && !stristr($link['href'],$site_url)) {
						$target_issue = true;
					}
				} else {
					$remote = wp_remote_head($site_url . $link['href']);
				}

				if(!is_wp_error($remote)) {
					if ($remote['response']['code'] != "200" || $target_issue) {
						$json['content'] .= "<div class='twg-report-item has-issue'>";
						$json['content'] .= "<div class='twg-report-info'>" . $link['href'] . "</div>";
						if ($remote['response']['code'] != "200") {
							$json['content'] .= "<div class='twg-report-issue'>ISSUE: " . $remote['response']['code'] . "</div>";
						}
						if ($target_issue) {
							$json['content'] .= "<div class='twg-report-issue'>ISSUE: External link does not open in a new window.</div>";
						}
					} else {
						$json['content'] .= "<div class='twg-report-item no-issue'>";
						$json['content'] .= "<div class='twg-report-info'>" . $link['href'] . "</div>";
					}
					$json['content'] .= "</div>";
				} else {
					$json['content'] .= "<div class='twg-report-item has-issue'>";
					$json['content'] .= "<div class='twg-report-info'>" . $link['href'] . "</div>";
					$json['content'] .= "<div class='twg-report-issue'>ISSUE: Most likely invalid URL view error below.</div>";
					$json['content'] .= pre_print($remote->errors,true);
					$json['content'] .= "</div>";
				}




			}
		} else {
			$json['content'] .= "<div class='twg-report-item'>";
			$json['content'] .= "<div class='twg-report-info'>No links on this page</div>";
			$json['content'] .= "</div>";
		}

		//Image alt tag checking
		$images = $this->get_images($footer);
		$json['content'] .= "<h3>Image Scan</h3>";
		$image_count = 0;
		$alt_missing = 0;
		$image_issue = "";
		$alt_tags = "";
		if($images) {
			foreach ($images as $image) {
				if (trim($image['alt']) != "") {
					$alt_tags .= "<div class='twg-report-info'><span>ALT:</span> " . $image['alt'] . "</div>";
				} else {
					$alt_missing++;
				}
				$image_count++;
			}
			if ($alt_missing) {
				$json['content'] .= "<div class='twg-report-item has-issue'>";
				$json['content'] .= "<div class='twg-report-issue'>Alt Text missing from $alt_missing image(s)</div>";
				$json['content'] .= "<div class='twg-report-info'><span>Image Count:</span> " . $image_count . "</div>";
				$json['content'] .= $alt_tags;
			} else {
				$json['content'] .= "<div class='twg-report-item no-issue'>";
				$json['content'] .= "<div class='twg-report-info'><span>Image Count:</span> " . $image_count . "</div>";
				$json['content'] .= $alt_tags;
			}

			$json['content'] .= "</div>";
		} else {
			$json['content'] .= "<div class='twg-report-item'>";
			$json['content'] .= "<div class='twg-report-info'>No images on this page</div>";
			$json['content'] .= "</div>";
		}

		$json['content'] .= "</div>";
		return $json;
	}

	public function header_report() {
		$json['content'] = '';
		$site_url = get_site_url();
		$footer = $this->get_header_content();

		$links = $this->get_links($footer);
		$json['content'] .= "<div class='twg-report-panel'>";
		$json['content'] .= "<h2><span>Header Content</span>  </h2>";

		//Link Scanning
		$json['content'] .= "<h3>Link Scan</h3>";
		if($links) {
			foreach ($links as $link) {

				if(substr(trim($link['href']),0,1)=="#" || stristr($link['href'],"tel:") || stristr($link['href'],"mailto:") || stristr($link['href'],"sms:")) {
					continue;
				}

				if(stristr($link['href'],"#")){
					$link['href'] = explode("#",$link['href'])[0];
				}

				$target_issue = false;
				if (stristr($link['href'], "http://") || stristr($link['href'], "https://")) {
					$remote = wp_remote_head($link['href']);
					if ($link['target'] != "_blank" && !stristr($link['href'],$site_url)) {
						$target_issue = true;
					}
				} else {
					$remote = wp_remote_head($site_url . $link['href']);
				}

				if(!is_wp_error($remote)) {
					if ($remote['response']['code'] != "200" || $target_issue) {
						$json['content'] .= "<div class='twg-report-item has-issue'>";
						$json['content'] .= "<div class='twg-report-info'>" . $link['href'] . "</div>";
						if ($remote['response']['code'] != "200") {
							$json['content'] .= "<div class='twg-report-issue'>ISSUE: " . $remote['response']['code'] . "</div>";
						}
						if ($target_issue) {
							$json['content'] .= "<div class='twg-report-issue'>ISSUE: External link does not open in a new window.</div>";
						}
					} else {
						$json['content'] .= "<div class='twg-report-item no-issue'>";
						$json['content'] .= "<div class='twg-report-info'>" . $link['href'] . "</div>";
					}
					$json['content'] .= "</div>";
				} else {
					$json['content'] .= "<div class='twg-report-item has-issue'>";
					$json['content'] .= "<div class='twg-report-info'>" . $link['href'] . "</div>";
					$json['content'] .= "<div class='twg-report-issue'>ISSUE: Most likely invalid URL view error below.</div>";
					$json['content'] .= pre_print($remote->errors,true);
					$json['content'] .= "</div>";
				}




			}
		} else {
			$json['content'] .= "<div class='twg-report-item'>";
			$json['content'] .= "<div class='twg-report-info'>No links on this page</div>";
			$json['content'] .= "</div>";
		}

		//Image alt tag checking
		$images = $this->get_images($footer);
		$json['content'] .= "<h3>Image Scan</h3>";
		$image_count = 0;
		$alt_missing = 0;
		$image_issue = "";
		$alt_tags = "";
		if($images) {
			foreach ($images as $image) {
				if (trim($image['alt']) != "") {
					$alt_tags .= "<div class='twg-report-info'><span>ALT:</span> " . $image['alt'] . "</div>";
				} else {
					$alt_missing++;
				}
				$image_count++;
			}
			if ($alt_missing) {
				$json['content'] .= "<div class='twg-report-item has-issue'>";
				$json['content'] .= "<div class='twg-report-issue'>Alt Text missing from $alt_missing image(s)</div>";
				$json['content'] .= "<div class='twg-report-info'><span>Image Count:</span> " . $image_count . "</div>";
				$json['content'] .= $alt_tags;
			} else {
				$json['content'] .= "<div class='twg-report-item no-issue'>";
				$json['content'] .= "<div class='twg-report-info'><span>Image Count:</span> " . $image_count . "</div>";
				$json['content'] .= $alt_tags;
			}

			$json['content'] .= "</div>";
		} else {
			$json['content'] .= "<div class='twg-report-item'>";
			$json['content'] .= "<div class='twg-report-info'>No images on this page</div>";
			$json['content'] .= "</div>";
		}

		$json['content'] .= "</div>";
		return $json;
	}
	public function widgets_report() {
		$json['content'] = '';
		$widgets = $this->get_widget_content();
		$site_url = get_site_url();

		foreach($widgets as $widget) {
			if($widget['content']) {
				$widget['text'] = $widget['content'];
			}
			$json['content'] .= "<div class='twg-report-panel'>";
			$links = $this->get_links($widget['text']);
			$json['content'] .= "<h2><span>Widget:</span>  ".$widget['title']." </h2>";

			//Link Scanning
			$json['content'] .= "<h3>Link Scan</h3>";
			if($links) {
				foreach ($links as $link) {

					if(substr(trim($link['href']),0,1)=="#" || stristr($link['href'],"tel:") || stristr($link['href'],"mailto:") || stristr($link['href'],"sms:")) {
						continue;
					}

					if(stristr($link['href'],"#")){
						$link['href'] = explode("#",$link['href'])[0];
					}

					$target_issue = false;
					if (stristr($link['href'], "http://") || stristr($link['href'], "https://")) {
						$remote = wp_remote_head($link['href']);
						if ($link['target'] != "_blank" && !stristr($link['href'],$site_url)) {
							$target_issue = true;
						}
					} else {
						$remote = wp_remote_head($site_url . $link['href']);
					}

					if(!is_wp_error($remote)) {
						if ($remote['response']['code'] != "200" || $target_issue) {
							$json['content'] .= "<div class='twg-report-item has-issue'>";
							$json['content'] .= "<div class='twg-report-info'>" . $link['href'] . "</div>";
							if ($remote['response']['code'] != "200") {
								$json['content'] .= "<div class='twg-report-issue'>ISSUE: " . $remote['response']['code'] . "</div>";
							}
							if ($target_issue) {
								$json['content'] .= "<div class='twg-report-issue'>ISSUE: External link does not open in a new window.</div>";
							}
						} else {
							$json['content'] .= "<div class='twg-report-item no-issue'>";
							$json['content'] .= "<div class='twg-report-info'>" . $link['href'] . "</div>";
						}
						$json['content'] .= "</div>";
					} else {
						$json['content'] .= "<div class='twg-report-item has-issue'>";
						$json['content'] .= "<div class='twg-report-info'>" . $link['href'] . "</div>";
						$json['content'] .= "<div class='twg-report-issue'>ISSUE: Most likely invalid URL view error below.</div>";
						$json['content'] .= pre_print($remote->errors,true);
						$json['content'] .= "</div>";
					}




				}
			} else {
				$json['content'] .= "<div class='twg-report-item'>";
				$json['content'] .= "<div class='twg-report-info'>No links on this page</div>";
				$json['content'] .= "</div>";
			}

			//Image alt tag checking
			$images = $this->get_images($widget['text']);
			$json['content'] .= "<h3>Image Scan</h3>";
			$image_count = 0;
			$alt_missing = 0;
			$image_issue = "";
			$alt_tags = "";
			if($images) {
				foreach ($images as $image) {
					if (trim($image['alt']) != "") {
						$alt_tags .= "<div class='twg-report-info'><span>ALT:</span> " . $image['alt'] . "</div>";
					} else {
						$alt_missing++;
					}
					$image_count++;
				}
				if ($alt_missing) {
					$json['content'] .= "<div class='twg-report-item has-issue'>";
					$json['content'] .= "<div class='twg-report-issue'>Alt Text missing from $alt_missing image(s)</div>";
					$json['content'] .= "<div class='twg-report-info'><span>Image Count:</span> " . $image_count . "</div>";
					$json['content'] .= $alt_tags;
				} else {
					$json['content'] .= "<div class='twg-report-item no-issue'>";
					$json['content'] .= "<div class='twg-report-info'><span>Image Count:</span> " . $image_count . "</div>";
					$json['content'] .= $alt_tags;
				}

				$json['content'] .= "</div>";
			} else {
				$json['content'] .= "<div class='twg-report-item'>";
				$json['content'] .= "<div class='twg-report-info'>No images on this page</div>";
				$json['content'] .= "</div>";
			}
			$json['content'] .= "</div>";
		}
		return $json;
	}

	/* Find unique phone numbers throughout the website */
	public function phone_report() {
		$json['content'] = "<h1 class='twg-section-header'>Report Section</h1>";
		$json['content'] .= "<div class='twg-report-panel'>";
		$json['content'] .= "<div class='twg-report-section twg-phone-report'>";
		$phone_numbers = array();
		$pages = $this->get_page_post_info('page');
		foreach($pages as $page) {
			$links = $this->get_links($page['content']);
			foreach($links as $link) {
				if(stristr($link['href'],"tel:")) {
					$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers($link['href']));
				}
			}
			$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers(wp_strip_all_tags($page['content'])));
			$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers($page['meta_description']));
			$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers($page['meta_title']));
		}

		$posts = $this->get_page_post_info('post');
		foreach($posts as $post) {
			$links = $this->get_links($post['content']);
			foreach($links as $link) {
				if(stristr($link['href'],"tel:")) {
					$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers($link['href']));
				}
			}
			$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers(wp_strip_all_tags($post['content'])));
			$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers($post['meta_description']));
			$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers($post['meta_title']));
		}

		$widgets = $this->get_widget_content();
		foreach($widgets as $widget) {
			if($widget['content']) {
				$widget['text'] = $widget['content'];
			}
			$links = $this->get_links($widget['text']);
			foreach($links as $link) {
				if(stristr($link['href'],"tel:")) {
					$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers($link['href']));
				}
			}
			$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers(wp_strip_all_tags($widget['text'])));
		}


		$footer = $this->get_footer_content();
		$links = $this->get_links($footer);
		foreach($links as $link) {
			if(stristr($link['href'],"tel:")) {
				$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers($link['href']));
			}
		}
		$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers(wp_strip_all_tags($footer)));

		$header = $this->get_header_content();
		$links = $this->get_links($header);
		foreach($links as $link) {
			if(stristr($link['href'],"tel:")) {
				$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers($link['href']));
			}
		}
		$phone_numbers = array_merge($phone_numbers, $this->get_matched_phone_numbers(wp_strip_all_tags($footer)));

		$phone_numbers = array_values(array_unique($phone_numbers));
		$json['content'] .= "<h2><span>Unique Phone Numbers</span> <small>In post, pages, widgets, header, and footer</small></h2>";
		$json['content'] .= "<ul>";
		if($phone_numbers) {
			foreach ($phone_numbers as $phone_number) {
				$json['content'] .= "<li>" . $phone_number . "</li>";
			}
		} else {
			$json['content'] .= "<li>No phone numbers found!</li>";
		}
		$json['content'] .= "</ul>";
		$json['content'] .= "</div>";
		$json['content'] .= "</div>";
		return $json;
	}

	/* Configure Gravity Forms Settings */
	public function gform_automate() {
		global $wpdb;
		$json = array();
		$json['content'] = "<h2>Configuring Gravity Forms Plugin</h2>";
		$json['content'] .= "<p>Temporarily Disabled Automation. Please check gravity forms for correct settings like anti-spam honeypot and enabling html5 fields if not enabled.</p>";
		/*
		if(is_plugin_active('gravityforms/gravityforms.php')){
			$form_ids = GFFormsModel::get_form_ids();

			foreach($form_ids as $form_id) {
				$display_meta = GFFormsModel::unserialize($wpdb->get_var("SELECT display_meta FROM ".$wpdb->prefix."rg_form_meta WHERE form_id='$form_id'"));
				$json['content'] .= "<div class='twg-primary'><span class='twg-label'>Checking Form:</span> ".$display_meta['title']."</div>";
				//Enable honeypot if not enabled.
				if(	!$display_meta['enableHoneypot'] ) {
					$display_meta['enableHoneypot'] = true;
					GFFormsModel::update_form_meta($form_id, $display_meta);
					$json['content'] .= "<div class='twg-secondary twg-success'>Enabled Anti-Spam Honeypot...</div>";
				} else {
					$json['content'] .= "<div class='twg-secondary twg-default'>Anti-Spam Honeypot is already enabled. Doing nothing...</div>";
				}
			}
			//Check if HTML 5 Inputs are enabled
			if(get_option("rg_gforms_enable_html5")==1){
				$json['content'] .= "<div class='twg-secondary twg-default'>Output HTML5 form fields option is already enabled. Doing nothing...</div>";
			} else {
				$json['content'] .= "<div class='twg-secondary twg-success'>Enabled Output HTML5 form fields...</div>";
				update_option("rg_gforms_enable_html5",1);
			}


		} else {
			$json['content'] .= "<p>Plugin not activated cannot configure.</p>";
		} */

		return $json;
	}



	/* Configure SEO Yoast Settings */
	public function yoast_automate() {
		$json = array();
		$json['content'] = "<h2>Configuring Yoast SEO Plugin</h2>";
		if(is_plugin_active('wordpress-seo/wp-seo.php')){
			$yoast_title_options = get_option("wpseo_titles");
			// Check if force rewrite enabled.
			if($yoast_title_options['forcerewritetitle']==1) {
				$json['content'] .= "<div class='twg-secondary twg-default'>Force rewrite titles already enabled. Doing nothing...</div>";
			} else {
				$json['content'] .= "<div class='twg-secondary twg-success'>Enabled force rewrite titles...</div>";
				$yoast_title_options['forcerewritetitle'] = 1;
			}

			// Check title separator
			if($yoast_title_options['separator']=="sc-raquo") {
				$json['content'] .= "<div class='twg-secondary twg-default'>Title separator already set correctly. Doing nothing</div>";
			} else {
				$json['content'] .= "<div class='twg-secondary twg-success'>Updated title separator...</div>";
				$yoast_title_options['separator'] = "sc-raquo";
			}

			//Setting no index no follows on correct types
			$json['content'] .= "<div class='twg-secondary twg-success'>Updated no index no follow on categories, tags, format, picture tag, archives ...</div>";
			$yoast_title_options['noindex-tax-post_format'] = 1;
			$yoast_title_options['noindex-subpages-wpseo'] =1;
			$yoast_title_options['noindex-tax-post_tag'] = 1;
			$yoast_title_options['noindex-author-wpseo'] = 1;
			$yoast_title_options['noindex-archive-wpseo'] = 1;
			$yoast_title_options['noindex-tax-category'] =1;
			$yoast_title_options['noindex-tax-ngg_tag'] = 1;


			update_option("wpseo_titles",$yoast_title_options,true);

			$yoast_xml = get_option("wpseo_xml");
			$json['content'] .= "<div class='twg-secondary twg-success'>Updated XML Sitemap options...</div>";
			$yoast_xml['disable_author_sitemap'] = 1;
			$yoast_xml['enablexmlsitemap'] = 1;
			$yoast_xml['post_types-attachment-not_in_sitemap'] = 1;
			$yoast_xml['taxonomies-category-not_in_sitemap'] = 1;
			$yoast_xml['taxonomies-post_tag-not_in_sitemap'] = 1;
			$yoast_xml['taxonomies-post_format-not_in_sitemap'] = 1;
			$yoast_xml['taxonomies-ngg_tag-not_in_sitemap'] = 1;

			update_option("wpseo_xml",$yoast_xml,true);

		} else {
			$json['content'] .= "<p>Plugin not activated cannot configure.</p>";
		}
		return $json;
	}


	public function clean_content_automate() {
		global $wpdb;
		$json = array();
		$json['content'] = "<h2>Content Clean Up</h2>";

		//Add trailing slash where needed
		#Posts & Pages
		$posts = $wpdb->get_results("SELECT ID, post_content FROM wp_posts WHERE post_type='post' OR post_type='page'",ARRAY_A);
		$trailing_info = array();
		$total_count = 0;
		foreach($posts as $post) {
			$trailing_info = $this->fix_trailing_slash($post['post_content']);
			$post['post_content'] = $trailing_info['content'];
			$wpdb->update("wp_posts",$post,array("ID"=>$post['ID']));
			$total_count += $trailing_info['count'];
		}
		if($total_count>0) {
			$json['content'] .= "<div class='twg-secondary twg-success'>Added missing trailing slashes to URLs in Post & Page Content...</div>";
		} else {
			$json['content'] .= "<div class='twg-secondary twg-default'>No missing trailing slashes on URLs in Post & Page Content. Doing nothing...</div>";
		}

		#Widgets
		$trailing_info = array();
		$total_count=0;
		$widgets = $this->get_widget_content();
		foreach($widgets as &$widget) {
			if($widget['content']) {
				$widget['text'] = $widget['content'];
			}
			$trailing_info = $this->fix_trailing_slash($widget['text']);
			$widget['text'] = $trailing_info['content'];
			$total_count += $trailing_info['count'];
		}
		if($total_count>0) {
			update_option("widget_text",$widgets,true);
			$json['content'] .= "<div class='twg-secondary twg-success'>Added missing trailing slashes to URLs in Text Widgets...</div>";
		} else {
			$json['content'] .= "<div class='twg-secondary twg-default'>No missing trailing slashes on URLs in Text Widgets. Doing nothing...</div>";
		}
		#Footer Area
		$trailing_info = array();
		$total_count=0;
		$footer_content = $this->get_footer_content();
		$trailing_info = $this->fix_trailing_slash($footer_content);
		$total_count += $trailing_info['count'];
		if($total_count>0) {
			$this->update_footer_content($trailing_info['content']);
			$json['content'] .= "<div class='twg-secondary twg-success'>Added missing trailing slashes to URLs in Footer Content...</div>";
		} else {
			$json['content'] .= "<div class='twg-secondary twg-default'>No missing trailing slashes on URLs in Footer Content. Doing nothing...</div>";
		}

		//Remove Hello World Post if it exists
		if(get_post_status(1)) {
			wp_delete_post(1,true);
			$json['content'] .= "<div class='twg-secondary twg-success'>Deleted Hello World post...</div>";
		} else {
			$json['content'] .= "<div class='twg-secondary twg-default'>Hello World post already deleted. Doing nothing...</div>";
		}

		return $json;
	}


	/* Configure general WP Settings */
	public function general_wp_automate() {
		$json = array();
		$json['content'] = "<h2>Configuring General WP Settings</h2>";

		//Comment notifications disabled
		if(get_option('comments_notify')==1 || get_option('moderation_notify')==1) {
			$json['content'] .= "<div class='twg-secondary twg-success'>Disabling comment notifications...</div>";
			update_option('comments_notify',0);
			update_option('moderation_notify',0);
		} else {
			$json['content'] .= "<div class='twg-secondary twg-default'>Comment notification already disabled. Doing nothing...</div>";
		}

		$json['content'] .= "<div class='twg-secondary twg-success'>Updated all plugins that needed updating...</div>";

		include_once( ABSPATH . 'wp-admin/includes/class-wp-upgrader.php' );


		$skin = new Automatic_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );

		$plugins = get_plugins();
		$plugins_update = array();
		foreach($plugins as $p => $plugin) {
			$plugins_update[] = $p;
		}
		$upgrader->bulk_upgrade($plugins_update);


		return $json;
	}

	private function get_page_post_info($type='page') {
		$args = array('post_type'=>$type,'posts_per_page'=>-1);
		$pages = get_posts($args);
		$pages_info = array();
		foreach($pages as $page){
			//Url (Permalink)
			$pages_info[$page->ID]['url'] = $page->post_name;

			if(class_exists("TWG_VariableEngine")) {
				$vars = TWG_VariableEngine();
				//Title
				$pages_info[$page->ID]['title'] =  $vars->replace_content_var($page->post_title);
				//Content
				$pages_info[$page->ID]['content'] =  $vars->replace_content_var($page->post_content);
				//SEO Data
				$pages_info[ $page->ID ]['meta_title']       = $vars->replace_content_var(get_post_meta( $page->ID, "_yoast_wpseo_title", true ));
				$pages_info[ $page->ID ]['meta_description'] = $vars->replace_content_var(get_post_meta( $page->ID, "_yoast_wpseo_metadesc", true ));
			} else {
				//Title
				$pages_info[$page->ID]['title'] =  $page->post_title;
				//Content
				$pages_info[$page->ID]['content'] =  $page->post_content;
				//SEO Data
				$pages_info[ $page->ID ]['meta_title']       = get_post_meta( $page->ID, "_yoast_wpseo_title", true );
				$pages_info[ $page->ID ]['meta_description'] = get_post_meta( $page->ID, "_yoast_wpseo_metadesc", true );
			}
		}
		return $pages_info;
	}

	//Text Widgets Only ( To Avoid any issues from third party plugins )
	private function get_widget_content() {
		$widgets_text = get_option("widget_text");
		$widgets_html = get_option("widget_custom_html");
		$widgets = array_merge($widgets_text,$widgets_html);
		return $widgets;
	}


	private function get_header_content() {

		if(function_exists('twg_material_option')) {
			return twg_material_option("header_content");
		} else {
			return "";
		}

	}

	private function get_footer_content() {

		if(function_exists('twg_material_option')) {
			return twg_material_option("footer_content");
		} else {
			$options = get_option("shoestrap");
			return $options['footer_text'];
		}

	}

	private function update_footer_content($footer_content) {
		if(!function_exists('twg_material_option')) {
			$options                = get_option( "shoestrap" );
			$options['footer_text'] = $footer_content;
			update_option( 'shoestrap', $options, true );
		}
	}

	/**
	 * Wrapper function to register a new post type
	 * @param  string $post_type   Post type name
	 * @param  string $plural      Post type item plural name
	 * @param  string $single      Post type item single name
	 * @param  string $description Description of post type
	 * @return object              Post type class object
	 */
	public function register_post_type ( $post_type = '', $plural = '', $single = '', $description = '', $options = array() ) {

		if ( ! $post_type || ! $plural || ! $single ) return;

		$post_type = new TWG_Automation_Checklist_Post_Type( $post_type, $plural, $single, $description, $options );

		return $post_type;
	}

	/**
	 * Wrapper function to register a new taxonomy
	 * @param  string $taxonomy   Taxonomy name
	 * @param  string $plural     Taxonomy single name
	 * @param  string $single     Taxonomy plural name
	 * @param  array  $post_types Post types to which this taxonomy applies
	 * @return object             Taxonomy class object
	 */
	public function register_taxonomy ( $taxonomy = '', $plural = '', $single = '', $post_types = array(), $taxonomy_args = array() ) {

		if ( ! $taxonomy || ! $plural || ! $single ) return;

		$taxonomy = new TWG_Automation_Checklist_Taxonomy( $taxonomy, $plural, $single, $post_types, $taxonomy_args );

		return $taxonomy;
	}

	private function backup_database() {
		$json['content'] = "<h1 class='twg-section-header'>Automation Section</h1>";
		$json['content'] .= "<h2>Backing up database ( Just in case )</h2>";
		$result = exec("mysqldump --user=".DB_USER." --password=".DB_PASSWORD." --host=".DB_HOST."  ".DB_NAME." > ".$this->assets_dir."/backup/db_backup.sql");
		$json['content'] .= "<div class='twg-secondary twg-success'>Back up completed...</div>";

		return $json;
	}



	/**
	 * Load frontend CSS.
	 * @access  public
	 * @since   1.0.0
	 * @return void
	 */
	public function enqueue_styles () {
		wp_register_style( $this->_token . '-frontend', esc_url( $this->assets_url ) . 'css/frontend.css', array(), $this->_version );
		wp_enqueue_style( $this->_token . '-frontend' );
	} // End enqueue_styles ()

	/**
	 * Load frontend Javascript.
	 * @access  public
	 * @since   1.0.0
	 * @return  void
	 */
	public function enqueue_scripts () {
		wp_register_script( $this->_token . '-frontend', esc_url( $this->assets_url ) . 'js/frontend' . $this->script_suffix . '.js', array( 'jquery' ), $this->_version );
		wp_enqueue_script( $this->_token . '-frontend' );
	} // End enqueue_scripts ()

	/**
	 * Load admin CSS.
	 * @access  public
	 * @since   1.0.0
	 * @return  void
	 */
	public function admin_enqueue_styles ( $hook = '' ) {
		wp_register_style( $this->_token . '-admin', esc_url( $this->assets_url ) . 'css/admin.css', array(), $this->_version );
		wp_enqueue_style( $this->_token . '-admin' );
	} // End admin_enqueue_styles ()

	/**
	 * Load admin Javascript.
	 * @access  public
	 * @since   1.0.0
	 * @return  void
	 */
	public function admin_enqueue_scripts ( $hook = '' ) {
		wp_register_script( $this->_token . '-admin', esc_url( $this->assets_url ) . 'js/admin' . $this->script_suffix . '.js', array( 'jquery' ), $this->_version );
		wp_enqueue_script( $this->_token . '-admin' );
	} // End admin_enqueue_scripts ()

	/**
	 * Load plugin localisation
	 * @access  public
	 * @since   1.0.0
	 * @return  void
	 */
	public function load_localisation () {
		load_plugin_textdomain( 'twg-automation-checklist', false, dirname( plugin_basename( $this->file ) ) . '/lang/' );
	} // End load_localisation ()

	/**
	 * Load plugin textdomain
	 * @access  public
	 * @since   1.0.0
	 * @return  void
	 */
	public function load_plugin_textdomain () {
		$domain = 'twg-automation-checklist';

		$locale = apply_filters( 'plugin_locale', get_locale(), $domain );

		load_textdomain( $domain, WP_LANG_DIR . '/' . $domain . '/' . $domain . '-' . $locale . '.mo' );
		load_plugin_textdomain( $domain, false, dirname( plugin_basename( $this->file ) ) . '/lang/' );
	} // End load_plugin_textdomain ()

	/**
	 * Main TWG_Automation_Checklist Instance
	 *
	 * Ensures only one instance of TWG_Automation_Checklist is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @static
	 * @see TWG_Automation_Checklist()
	 * @return Main TWG_Automation_Checklist instance
	 */
	public static function instance ( $file = '', $version = '1.0.0' ) {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self( $file, $version );
		}
		return self::$_instance;
	} // End instance ()

	/**
	 * Cloning is forbidden.
	 *
	 * @since 1.0.0
	 */
	public function __clone () {
		_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?' ), $this->_version );
	} // End __clone ()

	/**
	 * Unserializing instances of this class is forbidden.
	 *
	 * @since 1.0.0
	 */
	public function __wakeup () {
		_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?' ), $this->_version );
	} // End __wakeup ()

	/**
	 * Installation. Runs on activation.
	 * @access  public
	 * @since   1.0.0
	 * @return  void
	 */
	public function install () {
		$this->_log_version_number();
	} // End install ()


	function fix_trailing_slash($content) {

		$trailing_info = array();
		$trailing_info['count']  = 0;
		$dom = new DOMDocument();
		$dom->loadHTML($content);
		$xpath = new DOMXPath( $dom );
		// find all nodes containing an href attribute, and return the attribute node
		$linkNodes = $xpath->query( '//*[@href]/@href' );

		// initialize a result array
		$result = array();

		// iterate all found attribute nodes
		foreach( $linkNodes as $linkNode )
		{
			$slash_explode = explode("/",$linkNode->value);
			$slash_end = end($slash_explode);
			// does its value not end with a forward slash?
			if( !stristr($linkNode->value,"http://") && !stristr($linkNode->value,"https://") && substr( $linkNode->value, -1 ) !== '/' && !stristr($slash_end,".") && !stristr($slash_end,"#") && !stristr($slash_end,"?")  && !stristr($slash_end,"&") && trim($linkNode->value)!="")
			{
				$content = str_replace($linkNode->value . '"', $linkNode->value . '/"', $content);
				$content = str_replace($linkNode->value . "'", $linkNode->value . "/'", $content);
				$trailing_info['count']++;
			}
		}
		$trailing_info['content'] = $content;

		return $trailing_info;

	}


	/**
	 * Log the plugin version number.
	 * @access  public
	 * @since   1.0.0
	 * @return  void
	 */
	private function _log_version_number () {
		update_option( $this->_token . '_version', $this->_version );
	} // End _log_version_number ()

	public function get_stop_words() {
		return array(
			'-',
			'a',
			'about',
			'above',
			'after',
			'again',
			'against',
			'all',
			'also',
			'am',
			'an',
			'and',
			'any',
			'are',
			"aren't",
			'as',
			'at',
			'be',
			'because',
			'been',
			'before',
			'being',
			'below',
			'between',
			'both',
			'but',
			'by',
			"can't",
			'can',
			'cannot',
			'could',
			"couldn't",
			'did',
			"didn't",
			'do',
			'does',
			"doesn't",
			'doing',
			"don't",
			'down',
			'during',
			'each',
			'few',
			'for',
			'from',
			'further',
			'had',
			"hadn't",
			'has',
			"hasn't",
			'have',
			"haven't",
			'having',
			'he',
			"he'd",
			"he'll",
			"he's",
			'her',
			'here',
			"here's",
			'hers',
			'herself',
			'him',
			'himself',
			'his',
			'how',
			"how's",
			'i',
			"i'd",
			"i'll",
			"i'm",
			"i've",
			'if',
			'in',
			'into',
			'is',
			"isn't",
			'it',
			"it's",
			'its',
			'itself',
			"let's",
			'me',
			'more',
			'most',
			"mustn't",
			'my',
			'myself',
			'no',
			'nor',
			'not',
			'of',
			'off',
			'on',
			'once',
			'only',
			'or',
			'other',
			'ought',
			'our',
			'ours',
			'ourselves',
			'out',
			'over',
			'own',
			'same',
			"shan't",
			'she',
			"she'd",
			"she'll",
			"she's",
			'should',
			"shouldn't",
			'so',
			'some',
			'such',
			'than',
			'that',
			"that's",
			'the',
			'their',
			'theirs',
			'them',
			'themselves',
			'then',
			'there',
			"there's",
			'these',
			'they',
			"they'd",
			"they'll",
			"they're",
			"they've",
			'this',
			'those',
			'through',
			'to',
			'too',
			'under',
			'until',
			'up',
			'us',
			'very',
			'was',
			"wasn't",
			'we',
			"we'd",
			"we'll",
			"we're",
			"we've",
			'were',
			"weren't",
			'what',
			"what's",
			'when',
			"when's",
			'where',
			"where's",
			'which',
			'while',
			'who',
			"who's",
			'whom',
			'why',
			"why's",
			'with',
			"won't",
			'would',
			"wouldn't",
			'you',
			"you'd",
			"you'll",
			"you're",
			"you've",
			'your',
			'yours',
			'yourself',
			'yourselves',
			'zero'
		);
	}

}