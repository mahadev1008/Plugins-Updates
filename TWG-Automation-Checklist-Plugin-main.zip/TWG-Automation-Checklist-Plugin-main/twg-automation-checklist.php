<?php
/*
 * Plugin Name: TWG Automation Checklist
 * Version: 1.6.1
 * Plugin URI: http://www.the-web-guys.com/
 * Description: TWG Automation Checklist Plugin
 * Author: The Web Guys
 * Author URI: http://www.the-web-guys.com/
 * Requires at least: 4.0
 * Tested up to: 6.1.1
 *
 * Text Domain: twg-automation-checklist
 * Domain Path: /lang/
 *
 * @package WordPress
 * @author Ben Tucker
 * @since 1.3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Load plugin class files
if(!class_exists('simple_html_dom')) {
	require_once( 'includes/lib/simple_html_dom.php' );
}
require_once( 'includes/class-twg-automation-checklist.php' );
require_once( 'includes/class-twg-automation-checklist-settings.php' );

// Load plugin libraries
require_once( 'includes/lib/class-twg-automation-checklist-admin-api.php' );
require_once( 'includes/lib/class-twg-automation-checklist-post-type.php' );
require_once( 'includes/lib/class-twg-automation-checklist-taxonomy.php' );

if(!function_exists('pre_print')){
	function pre_print($val, $return = false){
		$display = "<pre>";
		$display .= print_r($val,true);
		$display .= "</pre>";

		if($return) {
			return $display;
		} else {
			echo $display;
		}
	}
}

/**
 * Returns the main instance of TWG_Automation_Checklist to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return object TWG_Automation_Checklist
 */
if(!function_exists('TWG_Automation_Checklist')) {
	function TWG_Automation_Checklist()
	{
		$instance = TWG_Automation_Checklist::instance(__FILE__, '1.6.1');
		return $instance;
	}
	add_action("plugins_loaded", 'TWG_Automation_Checklist');
}

/**
 * Plugin version update checker.
 */
require 'plugin-update-checker/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://github.com/TWGHQ/TWG-Automation-Checklist-Plugin',
	__FILE__,
	'twg-automation-checklist'
);

//Set the branch that contains the stable release.
$myUpdateChecker->setBranch('master');

//Optional: If you're using a private repository, specify the access token like this:
$myUpdateChecker->setAuthentication('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');
$myUpdateChecker->getVcsApi()->enableReleaseAssets();