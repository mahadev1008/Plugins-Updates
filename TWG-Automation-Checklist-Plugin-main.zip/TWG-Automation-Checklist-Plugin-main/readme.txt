=== TWG Automation Checklist ===
Contributors: btuck
Tags: wordpress, plugin, template
Requires at least: 4.0
Tested up to: 6.1.1
Stable tag: 1.6.1
License: No License ( Private Use )

Generates Report and Automates Plugin,and Theme Updates.

== Description ==

The Web Guys Automation Checklist Plugin

== Installation ==

From your WordPress dashboard

1. **Visit** Plugins > Add New
2. **Click** Upload Plugin
3. **Upload** Choose File, then select the plugin's .zip file. Click Install Now.
4. **Activate** the plugin.

== Changelog ==

= 1.6.0 =
*Introduced

= 1.6.1 =
*There has been no significant change since it was first introduced.

